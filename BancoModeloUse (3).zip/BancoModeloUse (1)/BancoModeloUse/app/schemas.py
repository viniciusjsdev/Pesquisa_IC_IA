# app/schemas.py
from pydantic import BaseModel
from datetime import datetime, date
from typing import Optional

class IndicadorResponse(BaseModel):
    indicador_nome: str
    valor: float
    unidade: Optional[str] = None
    detalhe: Optional[str] = None

class OrdemKPIResponse(BaseModel):
    ordem_producao_id: int
    eficiencia_percent: float
    taxa_defeitos_percent: float
    energia_por_unidade_kwh: float
    tempo_total_min: float

    class Config:
        orm_mode = True
