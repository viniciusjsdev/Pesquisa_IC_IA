from fastapi import FastAPI
from app.db import engine, Base
from app.models import (
    CustoPadrao, CustoIndiretoRateio, MaterialCustoHistorico, CustoMaoObraHistorico,
    CustoOperacionalVariavel, ContaContabil, LancamentoFinanceiro, Venda, Orcamento,
    KPIGerencial, CategoriaContabilPadrao, SubcategoriaContabilPadrao, ContaContabilDetalhe
)
from app.api.financeiro_router import router as financeiro_router

app = FastAPI(title="Descomplica Hub - Financeiro")

# Cria tabelas (apenas para dev; em prod use Alembic)
Base.metadata.create_all(bind=engine)

app.include_router(financeiro_router)

@app.get("/")
def root():
    return {"service": "descomplica hub - financeiro", "modules": ["financeiro"]}

